# redux-saga-sandbox
A console-based Redux Saga sandbox

## About
Use this tool to learn Redux Saga in a responsive, browser-based environment.

## Installation and Getting Started

Enusre you have installed `nodejs` from https://nodejs.org/. Something >= 6.x should be fine., You will also need to have a version of `npm` >= 5.2.

To install dependencies and start the application run the following commands:

`npm install`

`npm start`

Visit `http://localhost:8082` using Chrome
