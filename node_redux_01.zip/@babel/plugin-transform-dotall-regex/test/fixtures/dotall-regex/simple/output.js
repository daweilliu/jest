var a = /./;
var b = /[\0-\uFFFF]/;
