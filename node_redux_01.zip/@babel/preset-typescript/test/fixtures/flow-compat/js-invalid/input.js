enum Example {
  Value
}

foo;
