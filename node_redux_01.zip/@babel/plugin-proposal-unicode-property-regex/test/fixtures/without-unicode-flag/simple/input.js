var regex = /\p{ASCII_Hex_Digit}/u;
