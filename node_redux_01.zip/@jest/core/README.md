# @jest/core

Jest is currently working on providing a programmatic API. This is under developemnt, and usage of this package directly is currently not supported.
