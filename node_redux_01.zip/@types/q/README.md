# Installation
> `npm install --save @types/q`

# Summary
This package contains type definitions for Q ( https://github.com/kriskowal/q ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/q

Additional Details
 * Last updated: Wed, 13 Mar 2019 17:15:46 GMT
 * Dependencies: none
 * Global values: Q

# Credits
These definitions were written by Barrie Nemetchek <https://github.com/bnemetchek>, Andrew Gaspar <https://github.com/AndrewGaspar>, John Reilly <https://github.com/johnnyreilly>, Michel Boudreau <https://github.com/mboudreau>, TeamworkGuy2 <https://github.com/TeamworkGuy2>.
