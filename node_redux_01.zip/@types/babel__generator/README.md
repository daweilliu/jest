# Installation
> `npm install --save @types/babel__generator`

# Summary
This package contains type definitions for @babel/generator ( https://github.com/babel/babel/tree/master/packages/babel-generator ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babel__generator

Additional Details
 * Last updated: Wed, 13 Feb 2019 21:04:23 GMT
 * Dependencies: @types/babel__types
 * Global values: none

# Credits
These definitions were written by Troy Gerwien <https://github.com/yortus>, Johnny Estilles <https://github.com/johnnyestilles>, Melvin Groenhoff <https://github.com/mgroenhoff>.
