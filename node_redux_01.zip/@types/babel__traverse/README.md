# Installation
> `npm install --save @types/babel__traverse`

# Summary
This package contains type definitions for @babel/traverse ( https://github.com/babel/babel/tree/master/packages/babel-traverse ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babel__traverse

Additional Details
 * Last updated: Tue, 11 Jun 2019 02:00:21 GMT
 * Dependencies: @types/babel__types
 * Global values: none

# Credits
These definitions were written by Troy Gerwien <https://github.com/yortus>, Marvin Hagemeister <https://github.com/marvinhagemeister>, Ryan Petrich <https://github.com/rpetrich>, Melvin Groenhoff <https://github.com/mgroenhoff>.
