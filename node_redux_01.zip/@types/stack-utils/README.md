# Installation
> `npm install --save @types/stack-utils`

# Summary
This package contains type definitions for stack-utils (https://github.com/tapjs/stack-utils#readme).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/stack-utils

Additional Details
 * Last updated: Tue, 07 Nov 2017 17:49:01 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by BendingBender <https://github.com/BendingBender>.
