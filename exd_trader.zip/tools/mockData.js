const orders = [
  {
    id: 1,
    action: "Buy",
    symbol: "AAPL",
    qty: 121,
    tif: "GTC",
    price: 121,
    stopPrice: 2323,
    orderType: "Market",
    comment: "",
    lastUpdateTime: "2019-06-24T05:43:19.654Z",
    createdAt: 1561355013498,
    slug: "aapl"
  },
  {
    id: 2,
    action: "Sell",
    symbol: "MSFT",
    qty: 12,
    tif: "GTC",
    price: 121,
    stopPrice: 121,
    orderType: "Market",
    comment: "",
    lastUpdateTime: "2019-06-24T05:48:36.606Z",
    createdAt: 1561355327209,
    slug: "msft"
  },
  {
    id: 3,
    action: "Buy",
    symbol: "MSFT",
    qty: 12,
    tif: "GTC",
    price: 121,
    stopPrice: 12121,
    orderType: "Market",
    comment: "dddd",
    lastUpdateTime: "2019-06-24T05:52:21.063Z",
    createdAt: 1561355541145,
    slug: "msft"
  },
  {
    id: 4,
    action: "Buy",
    symbol: "AAPL",
    qty: 11,
    tif: "GTC",
    price: 11,
    stopPrice: 11,
    orderType: "Market",
    comment: "",
    lastUpdateTime: "2019-06-24T06:17:08.017Z",
    createdAt: 1561357028098,
    slug: "aapl"
  }
];

const newOrder = {
  id: null,
  action: "Buy",
  symbol: "",
  qty: "",
  tif: "DAY",
  price: null,
  stopPrice: null,
  orderType: "Marlet",
  comment: "",
  lastUpdateTime: null
};

const tifs = [
  { id: "GTC", tifName: "GTC" },
  { id: "DAY", tifName: "DAY" },
  { id: "FOK", tifName: "FOK" },
  { id: "IOC", tifName: "IOC" }
];

// Using CommonJS style export so we can consume via Node (without using Babel-node)
module.exports = {
  orders,
  newOrder,
  tifs
};
