import React, { Component } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-balham.css";
import PropTypes from "prop-types";
import { Row, Col, Layout } from "antd";

class OrderBlotterGrid extends Component {
  constructor(props) {
    super(props);
    this.getMaxTime.bind(this);
    this.state = {
      columnDefs: [
        {
          headerName: "Id",
          field: "id",
          hide: true,
          sortable: true
        },
        {
          headerName: "Action",
          field: "action",
          width: 80,
          sortable: true,
          cellStyle: function(params) {
            var color = actionToColor(params.value);
            return {
              backgroundColor: color
            };
          }
        },
        {
          headerName: "Symbol",
          field: "symbol",
          width: 85,
          sortable: true
        },
        {
          headerName: "Qty",
          field: "qty",
          width: 70,
          sortable: true
        },
        {
          headerName: "Order Type",
          field: "orderType",
          width: 95,
          sortable: true
        },
        {
          headerName: "TIF",
          field: "tif",
          width: 65
        },
        {
          headerName: "Price",
          field: "price",
          width: 70,
          sortable: true
        },
        {
          headerName: "Stop Price",
          field: "stopPrice",
          width: 100,
          sortable: true
        },
        {
          headerName: "Comment",
          field: "comment",
          width: 78,
          sortable: true,
          tooltipField: "comment"
        }
      ],
      lastUpdateTime: ""
    };

    function actionToColor(val) {
      if (val === "Buy") {
        return "green";
      } else {
        return "red";
      }
    }
  }
  getMaxTime(data) {
    if (!data) {
      return null;
    }
    if (data.length === 0) {
      return null;
    }
    const max = data.reduce(function(prev, current) {
      return prev.lastUpdateTime > current.lastUpdateTime ? prev : current;
    });
    return max.lastUpdateTime;
  }
  componentDidMount() {
    const { orders } = this.props;
    this.setState({ rowData: orders });
    const last = !orders ? null : this.getMaxTime(orders);
    if (last) {
      const localTime = new Date(Date.parse(last)).toLocaleTimeString();
      this.setState({ lastUpdateTime: "Last Update: " + localTime });
    }
  }
  render() {
    return (
      <div>
        <Layout className="layout">
          <Layout.Content>
            <div
              style={{ backgroundColor: "black", height: 40, marginBottom: 10 }}
            >
              <Row>
                <Col span={5}>
                  <h4
                    style={{
                      padding: "10px 20px",
                      textAlign: "left",
                      color: "white"
                    }}
                  >
                    Order Blotter
                  </h4>
                </Col>
                <Col span={19}>
                  <h4
                    style={{
                      padding: "10px 20px",
                      textAlign: "right",
                      color: "white"
                    }}
                  >
                    {this.state.lastUpdateTime}
                  </h4>
                </Col>
              </Row>
            </div>
            <div
              className="ag-theme-balham"
              style={{
                height: "450px",
                width: "650px"
              }}
            >
              <AgGridReact
                columnDefs={this.state.columnDefs}
                rowData={this.state.rowData}
                enableBrowserTooltips={true}
              />
            </div>
          </Layout.Content>
        </Layout>
      </div>
    );
  }
}

OrderBlotterGrid.propTypes = {
  orders: PropTypes.array.isRequired
};
export default OrderBlotterGrid;
