import React from "react";
import PropTypes from "prop-types";
import { Button, InputNumber, Form, Row, Col, Input, Layout } from "antd";

import SelectInputForTif from "../common/SelectInputForTif";
import SelectInputForAction from "../common/SelectInputForAction";
import SearchInputForSymbol from "../common/SearchInputForSymbol";
import SelectInputForOrderType from "../common/SelectInputForOrderType";

const OrderForm = ({
  order,
  onSave,
  onChange,
  saving = false,
  isDataValid = false
}) => {
  const { TextArea } = Input;
  const { Content } = Layout;
  const onChangeForTif = event => {
    onChange({ target: { value: event, name: "tif" } });
  };

  const onChangeForAction = event => {
    onChange({ target: { value: event, name: "action" } });
  };

  const onChangeOnSymbol = event => {
    onChange({ target: { value: event, name: "symbol" } });
  };

  const onChangeForOrderType = event => {
    onChange({ target: { value: event, name: "orderType" } });
  };

  const onChangeForQty = event => {
    onChange({ target: { value: event, name: "qty" } });
  };

  const onChangeForPrice = event => {
    onChange({ target: { value: event, name: "price" } });
  };

  const onChangeForStopPrice = event => {
    onChange({ target: { value: event, name: "stopPrice" } });
  };

  const onChangeComment = event => {
    onChange({ target: { value: event.target.value, name: "comment" } });
  };

  // const onChangeForAntControl = (event) => (fieldName) => {
  //   onChange({ target: { value: event, name: fieldName } });
  // };

  return (
    <div>
      <Layout className="layout">
        <Content>
          <div
            style={{ backgroundColor: "black", height: 40, marginBottom: 10 }}
          >
            <h4
              style={{
                padding: "10px 20px",
                textAlign: "left",
                color: "white"
              }}
            >
              EXD Trader Order Entry
            </h4>
          </div>
          <Form layout="vertical" onSubmit={onSave} style={{ paddingLeft: 20 }}>
            {/* {Form.resetFields()} */}
            <Row>
              <Col span={5}>
                <Form.Item label="Action">
                  <SelectInputForAction
                    name="action"
                    onChange={onChangeForAction}
                  />
                </Form.Item>
              </Col>
              <Col span={10}>
                <Form.Item label="Symbol">
                  <SearchInputForSymbol
                    name="symbol"
                    onChange={onChangeOnSymbol}
                  />
                </Form.Item>
              </Col>
              <Col span={4}>
                <Form.Item label="Qty">
                  <InputNumber
                    name="qty"
                    min={0}
                    max={999}
                    defaultValue={0}
                    onChange={onChangeForQty}
                  />
                </Form.Item>
              </Col>
              <Col span={5}>
                <Form.Item label="Price">
                  <InputNumber
                    name="price"
                    min={0}
                    max={999999}
                    precision={2}
                    defaultValue={0.0}
                    onChange={onChangeForPrice}
                  />
                </Form.Item>
              </Col>
            </Row>
            <Row>
              <Col span={5}>
                <Form.Item label="Order Type">
                  <SelectInputForOrderType
                    name="orderType"
                    onChange={onChangeForOrderType}
                  />
                </Form.Item>
              </Col>
              <Col span={10}>
                <Form.Item label="TIF">
                  <SelectInputForTif name="tif" onChange={onChangeForTif} />
                </Form.Item>
              </Col>
              <Col span={5} offset={4}>
                <Form.Item label="Stop Price">
                  <InputNumber
                    name="stopPrice"
                    min={0}
                    max={999999}
                    precision={2}
                    defaultValue={0.0}
                    onChange={onChangeForStopPrice}
                  />
                </Form.Item>
              </Col>
            </Row>
            <Row type="flex" justify="end" align="bottom">
              <Col span={14}>
                <Form.Item>
                  <TextArea
                    rows={4}
                    onChange={onChangeComment}
                    name="comment"
                    placeholder="<COMMENT>"
                    value={order.comment}
                  />
                </Form.Item>
              </Col>
              <Col span={5} offset={5}>
                <Form.Item>
                  <Button
                    rows={4}
                    disabled={saving || !isDataValid}
                    type="primary"
                    onClick={onSave}
                  >
                    {saving ? "Submiting..." : "Submit"}
                  </Button>
                </Form.Item>
              </Col>
            </Row>
          </Form>
        </Content>
      </Layout>
    </div>
  );
};

OrderForm.propTypes = {
  order: PropTypes.object,
  onSave: PropTypes.func.isRequired,
  onChange: PropTypes.func.isRequired,
  saving: PropTypes.bool,
  isDataValid: PropTypes.bool
};

export default OrderForm;
