import React, { Component } from "react";
import { connect } from "react-redux";
import * as orderActions from "../../redux/actions/orderActions";
import PropTypes from "prop-types";
import { bindActionCreators } from "redux";
import OrderBlotterGrid from "./OrderBlotterGrid";
import AntSpinner from "../common/AntSpinner";

class OrderBlotter extends Component {
  componentDidMount() {
    const { orders, actions } = this.props;

    if (orders.length === 0) {
      actions.loadOrders().catch(error => {
        alert("Loading order failed" + error);
      });
    }
  }

  render() {
    return (
      <>
        {this.props.loading ? (
          <AntSpinner />
        ) : (
          <>
            <OrderBlotterGrid orders={this.props.orders} />
          </>
        )}
      </>
    );
  }
}

OrderBlotter.propTypes = {
  orders: PropTypes.array.isRequired,
  actions: PropTypes.object.isRequired,
  loading: PropTypes.bool.isRequired
};

function mapStateToProps(state) {
  return {
    orders: state.orders,
    loading: state.apiCallsInProgress > 0
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      loadOrders: bindActionCreators(orderActions.loadOrders, dispatch)
    }
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(OrderBlotter);
