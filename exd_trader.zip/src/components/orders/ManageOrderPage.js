import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { loadOrders, saveOrder } from "../../redux/actions/orderActions";
import { loadTifs } from "../../redux/actions/tifActions";
import PropTypes from "prop-types";
import OrderForm from "./OrderForm";
import { newOrder } from "../../../tools/mockData";
import AntSpinner from "../common/AntSpinner";

function ManageOrderPage({ orders, tifs, loadTifs, saveOrder, ...props }) {
  const [order, setOrder] = useState({});
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [totalTrades, setTotalTrades] = useState(0);
  const [isDataValid, setIsDataValid] = useState(false);

  useEffect(() => {
    setOrder({ ...props.order });
    if (tifs.length === 0) {
      loadTifs().catch(error => {
        alert("Loading tifs failed" + error);
      });
    }
  }, [props.order]);

  function handleChange(event) {
    const { name, value } = event.target;
    setOrder(prevOrder => ({
      ...prevOrder,
      [name]: getFieldValue(name, value)
    }));
    if (!formIsValid()) {
      setIsDataValid(false);
    } else {
      setIsDataValid(true);
    }
  }

  const getFieldValue = (name, value) => {
    switch (name) {
      case "qty":
        return parseInt(value, 10);
      case "price":
      case "stopPrice":
        return parseFloat(value, 10);
      default:
        return !value ? "" : value;
    }
  };

  function formIsValid() {
    const { action, symbol, qty, tif, price, stopPrice, orderType } = order;
    const errors = {};

    if (!action) errors.action = "Action is required.";
    if (!symbol) errors.symbol = "Symbol is required.";
    if (!qty) errors.qty = "Qty is required.";
    if (!tif) errors.tif = "TIF is required.";
    if (!price) errors.price = "Price is required.";
    if (!stopPrice) errors.stopPrice = "Stop price is required.";
    if (!orderType) errors.orderType = "Order Type is required.";
    if (qty && qty > 999)
      errors.qty = errors.qty
        ? errors.qty + " Qty cannot be greater than 999."
        : "Qty cannot be greater than 999.";

    setErrors(errors);
    // Form is valid if the errors object still has no properties
    return Object.keys(errors).length === 0;
  }

  function handleSave(event) {
    event.preventDefault();
    if (!formIsValid()) return;
    setSaving(true);
    order.lastUpdateTime = new Date();
    saveOrder(order)
      .then(() => {
        setSaving(false);
        setIsDataValid(false);
        setTotalTrades(totalTrades + 1);
        if (totalTrades === 10) {
          setTotalTrades(0);
          alert("Order time has elapse");
        }
      })
      .catch(error => {
        setSaving(false);
        setErrors({ onSave: error.message });
      });
  }

  return tifs.length === 0 || !orders ? (
    <AntSpinner />
  ) : (
    <OrderForm
      order={order}
      onSave={handleSave}
      onChange={handleChange}
      saving={saving}
      isDataValid={isDataValid}
      errors={errors}
    />
  );
}

ManageOrderPage.propTypes = {
  order: PropTypes.object,
  tifs: PropTypes.array,
  orders: PropTypes.array,
  loadOrders: PropTypes.func,
  loadTifs: PropTypes.func,
  saveOrder: PropTypes.func
};

function mapStateToProps(state) {
  const order = newOrder;
  return {
    order,
    orders: state.orders,
    tifs: state.tifs
  };
}

const mapDispatchToProps = {
  loadOrders,
  loadTifs,
  saveOrder
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ManageOrderPage);
