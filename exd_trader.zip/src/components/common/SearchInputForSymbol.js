import React from "react";
import PropTypes from "prop-types";
import { Select } from "antd";

const { Option } = Select;

const SearchInputForSymbol = ({ name, onChange }) => {
  return (
    <div>
      <Select
        name={name}
        showSearch
        showArrow={false}
        autoFocus={true}
        notFoundContent="not found"
        style={{ width: 245 }}
        placeholder="input search text"
        optionFilterProp="children"
        onChange={onChange}
        filterOption={(input, option) =>
          option.props.children.toLowerCase().indexOf(input.toLowerCase()) === 0
        }
      >
        <Option value="AAPL">AAPL</Option>
        <Option value="MSFT">MSFT</Option>
        <Option value="GOOGL">GOOGL</Option>
        <Option value="VZ">VZ</Option>
        <Option value="MMM">MMM</Option>
        <Option value="NFLX">NFLX</Option>
        <Option value="FB">FB</Option>
        <Option value="TWTR">TWTR</Option>
        <Option value="AMZN">AMZN</Option>
        <Option value="EBAY">EBAY</Option>
      </Select>
    </div>
  );
};

SearchInputForSymbol.propTypes = {
  name: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired
};

export default SearchInputForSymbol;
