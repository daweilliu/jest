import React from "react";
import PropTypes from "prop-types";
import { Select } from "antd";

const { Option } = Select;

const SelectInputForAction = ({ name, onChange }) => {
  return (
    <Select
      name={name}
      showSearch
      style={{ width: 120 }}
      placeholder="select a action"
      autoFocus={true}
      // defaultValue="Buy"
      optionFilterProp="children"
      onChange={onChange}
      filterOption={(input, option) =>
        option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
      }
    >
      <Option value="Buy">Buy</Option>
      <Option value="Sell">Sell</Option>
    </Select>
  );
};

SelectInputForAction.propTypes = {
  name: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired
};

export default SelectInputForAction;
