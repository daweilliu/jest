import React from "react";
import { Spin } from "antd";
import "./AntSpinner.css";

const AntSpinner = () => {
  return (
    <div className="antSpin">
      <Spin size="large" />
    </div>
  );
};

export default AntSpinner;
