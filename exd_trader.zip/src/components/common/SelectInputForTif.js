import React from "react";
import PropTypes from "prop-types";
import { Select } from "antd";

const { Option } = Select;

const SelectInputForTif = ({ name, onChange }) => {
  return (
    <Select
      name={name}
      showSearch
      style={{ width: 120 }}
      placeholder="select a TIF"
      autoFocus={true}
      // defaultValue="DAY"
      optionFilterProp="children"
      onChange={onChange}
      filterOption={(input, option) =>
        option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
      }
    >
      <Option value="GTC">GTC</Option>
      <Option value="DAY">DAY</Option>
      <Option value="FOK">FOK</Option>
      <Option value="IOC">IOC</Option>
    </Select>
  );
};

SelectInputForTif.propTypes = {
  name: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired
};

export default SelectInputForTif;
