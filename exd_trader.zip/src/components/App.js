import React from "react";
import ManageOrderPage from "./orders/ManageOrderPage";
import OrderBlotter from "./orders/OrderBlotter";
// import { render } from "react-dom";
// import styled from "styled-components";
// import SplitView from "./SplitView";

// const Wrapper = styled.div`
//   height: 100vh;
// `;

// const App = () => (
//   <Wrapper>
//     <SplitView />
//   </Wrapper>
// );

function App() {
  return (
    <div>
      <div>
        <ManageOrderPage />
      </div>
      <div>
        <OrderBlotter />
      </div>
    </div>
  );
}

export default App;
