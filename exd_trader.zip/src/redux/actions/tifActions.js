import * as types from "./actionTypes";
import * as tifApi from "../../api/tifApi";
import { beginApiCall, apiCallError } from "./apiStatusActions";

export function loadTifsSuccess(tifs) {
  return { type: types.LOAD_TIFS_SUCCESS, tifs };
}

export function loadTifs() {
  return function(dispatch) {
    dispatch(beginApiCall());
    return tifApi
      .getTifs()
      .then(tifs => {
        dispatch(loadTifsSuccess(tifs));
      })
      .catch(error => {
        dispatch(apiCallError(error));
        throw error;
      });
  };
}
