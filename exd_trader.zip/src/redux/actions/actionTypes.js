export const CREATE_ORDER = "CREATE_ORDER";
export const LOAD_ORDERS_SUCCESS = "LOAD_ORDERS_SUCCESS";
export const LOAD_SYMBOLS_SUCCESS = "LOAD_SYMBOLS_SUCCESS";
export const CREATE_ORDER_SUCCESS = "CREATE_ORDER_SUCCESS";
export const UPDATE_ORDER_SUCCESS = "UPDATE_ORDER_SUCCESS";

export const LOAD_TIFS_SUCCESS = "LOAD_TIFS_SUCCESS";

export const BEGIN_API_CALL = "BEGIN_API_CALL";
export const API_CALL_ERROR = "API_CALL_ERROR";

// By convention, actions that end in "_SUCCESS" are assumed to have been the result of a completed
