import * as types from "./actionTypes";
import * as orderApi from "../../api/orderApi";
import { beginApiCall, apiCallError } from "./apiStatusActions";

export function loadOrderSuccess(orders) {
  return { type: types.LOAD_ORDERS_SUCCESS, orders };
}

export function createOrderSuccess(order) {
  return { type: types.CREATE_ORDER_SUCCESS, order };
}

export function updateOrderSuccess(order) {
  return { type: types.UPDATE_ORDER_SUCCESS, order };
}

export function loadOrders() {
  return function(dispatch) {
    dispatch(beginApiCall());
    return orderApi
      .getOrders()
      .then(orders => {
        dispatch(loadOrderSuccess(orders));
      })
      .catch(error => {
        dispatch(apiCallError(error));
        throw error;
      });
  };
}

export function saveOrder(order) {
  //eslint-disable-next-line no-unused-vars
  return function(dispatch, getState) {
    dispatch(beginApiCall());
    return orderApi
      .saveOrder(order)
      .then(savedzorder => {
        order.id
          ? dispatch(updateOrderSuccess(savedzorder))
          : dispatch(createOrderSuccess(savedzorder));
      })
      .catch(error => {
        dispatch(apiCallError(error));
        throw error;
      });
  };
}
