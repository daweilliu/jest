export default {
  orders: [],
  tifs: [],
  apiCallsInProgress: 0
};
