import { combineReducers } from "redux";
import tifs from "./tifReducer";
import orders from "./orderReducer";
import apiCallsInProgress from "./apiStatusReducer";

const rootReducer = combineReducers({
  tifs,
  orders,
  apiCallsInProgress
});

export default rootReducer;
