module.exports = require('./lib').elementType; // eslint-disable-line import/no-unresolved
