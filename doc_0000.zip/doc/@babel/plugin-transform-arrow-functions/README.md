# @babel/plugin-transform-arrow-functions

> Compile ES2015 arrow functions to ES5

See our website [@babel/plugin-transform-arrow-functions](https://babeljs.io/docs/en/next/babel-plugin-transform-arrow-functions.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-arrow-functions
```

or using yarn:

```sh
yarn add @babel/plugin-transform-arrow-functions --dev
```
