# Installation
> `npm install --save @types/babel__core`

# Summary
This package contains type definitions for @babel/core ( https://github.com/babel/babel/tree/master/packages/babel-core ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babel__core

Additional Details
 * Last updated: Wed, 15 May 2019 16:25:45 GMT
 * Dependencies: @types/babel__generator, @types/babel__traverse, @types/babel__template, @types/babel__types, @types/babel__parser
 * Global values: babel

# Credits
These definitions were written by Troy Gerwien <https://github.com/yortus>, Marvin Hagemeister <https://github.com/marvinhagemeister>, Melvin Groenhoff <https://github.com/mgroenhoff>, Jessica Franco <https://github.com/Jessidhia>.
