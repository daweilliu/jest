# Installation
> `npm install --save @types/istanbul-lib-report`

# Summary
This package contains type definitions for istanbul-lib-report ( https://istanbul.js.org ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/istanbul-lib-report

Additional Details
 * Last updated: Thu, 25 Apr 2019 23:07:44 GMT
 * Dependencies: @types/istanbul-lib-coverage
 * Global values: none

# Credits
These definitions were written by Jason Cheatham <https://github.com/jason0x43>.
