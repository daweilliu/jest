import isPlainObject from 'prop-types-exact/build/helpers/isPlainObject';

export default isPlainObject;
