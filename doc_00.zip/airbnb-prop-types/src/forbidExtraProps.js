import forbidExtraProps from 'prop-types-exact';

export default forbidExtraProps;
