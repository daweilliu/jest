require('@babel/register')({
  only: [/test\//],
});
